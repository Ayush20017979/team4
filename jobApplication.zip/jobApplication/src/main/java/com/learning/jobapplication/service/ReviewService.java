package com.learning.jobapplication.service;

import com.learning.jobapplication.model.Review;
import java.util.List;
import java.util.Optional;

public interface ReviewService {
    List<Review> getAllReviews(Long companyId);
    Optional<Review> getReview(Long id, Long companyId);
    int addReview(Review review, Long companyId);
    int updateReview(Long id, Review review, Long companyId);
    int deleteReview(Long id, Long companyId);
}