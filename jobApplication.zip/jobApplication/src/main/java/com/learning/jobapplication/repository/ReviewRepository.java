package com.learning.jobapplication.repository;

import com.learning.jobapplication.model.Review;
import java.util.List;
import java.util.Optional;

// Define the ReviewRepository interface
public interface ReviewRepository  {

    List<Review> findReviewsByCompanyId(Long companyId);
    Optional<Review> findReviewByIdAndCompanyId(Long id, Long companyId);
    int addReview(Review review, Long companyId);
    int updateReview(Long id, Review review, Long companyId);
    int deleteReview(Long id, Long companyId);
}