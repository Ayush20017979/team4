package com.learning.jobapplication.repository;

import com.learning.jobapplication.model.Company;
import com.learning.jobapplication.model.Job;
import com.learning.jobapplication.model.Review;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class CompanyRepositoryImpl implements CompanyRepository {

    private final JdbcTemplate jdbcTemplate;
    public CompanyRepositoryImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private Company mapRowToCompany(ResultSet rs) throws SQLException {
        return new Company(
                rs.getLong("company_id"),
                rs.getString("company_name"),
                rs.getString("company_description")
        );
    }

    private Job mapRowToJob(ResultSet rs) throws SQLException {
        return new Job(
                rs.getLong("job_id"),
                rs.getString("title"),
                rs.getString("description"),
                rs.getLong("company_id")
        );
    }

    private Review mapRowToReview(ResultSet rs) throws SQLException {
        return new Review(
                rs.getLong("review_id"),
                rs.getString("title"),
                rs.getString("description"),
                rs.getDouble("rating"),
                rs.getLong("company_id")
        );
    }

    @Override
    public Optional<Company> findCompanyById(Long companyId) {
        String sqlForCompany = "SELECT * FROM public.company WHERE company_id = ?";
        String sqlForJob = "SELECT * FROM public.job WHERE company_id = ?";
        String sqlForReview = "SELECT * FROM public.review WHERE company_id = ?";
        try {
            Optional<Company> optionalCompany = Optional.ofNullable(jdbcTemplate.queryForObject(sqlForCompany,(rs, row)->mapRowToCompany(rs),companyId));
            List<Job> jobs = jdbcTemplate.query(sqlForJob,(rs, row)->mapRowToJob(rs));
            List<Review> reviews = jdbcTemplate.query(sqlForReview,(rs, row)->mapRowToReview(rs));
            optionalCompany.ifPresent(company -> {
                company.setJobs(jobs);
                company.setReviews(reviews);
            });
            return optionalCompany;
        } catch (DataAccessException e) {
            return Optional.empty();
        }
    }

    @Override
    public List<Company> findAllCompanies() {
        String sqlForCompany = "SELECT * FROM public.company";
        try {
            List<Company> companies = jdbcTemplate.query(sqlForCompany,(rs, row)->mapRowToCompany(rs));
            if(!companies.isEmpty()) {
                companies.forEach(Company ->{
                    String sqlForJob = "SELECT * FROM public.job WHERE company_id = ?";
                    String sqlForReview = "SELECT * FROM public.review WHERE company_id = ?";
                    List<Job> jobs = jdbcTemplate.query(sqlForJob,(rs, row)->mapRowToJob(rs),Company.getCompanyId());
                    List<Review> reviews = jdbcTemplate.query(sqlForReview,(rs, row)->mapRowToReview(rs),Company.getCompanyId());
                    Company.setJobs(jobs);
                    Company.setReviews(reviews);
                });
            }
            return companies;
        } catch (DataAccessException e) {
            throw new RuntimeException("FindAll failed",e);
        }
    }

    @Override
    public int saveCompany(Company company) {
        String sql = "insert into public.company (company_name, company_description) values (?,?)";
        try {
            return jdbcTemplate.update(sql,company.getCompanyName(),company.getCompanyDescription());
        } catch (DataAccessException e) {
            throw new RuntimeException("Insert operation failed",e);
        }
    }

    @Override
    public int updateCompany(Company company) {
        String sql = "UPDATE public.company SET company_name = ?, company_description = ? WHERE company_id ";
        try {
            return jdbcTemplate.update(sql,company.getCompanyName(),company.getCompanyDescription(),company.getCompanyId());
        } catch (DataAccessException e) {
            throw new RuntimeException("Update operation failed",e);
        }
    }

    @Override
    public int deleteCompany(Long companyId) {
        String sqlForCompany = "DELETE FROM public.company WHERE company_id = ?";
        try {
            return jdbcTemplate.update(sqlForCompany,companyId);
        } catch (DataAccessException e) {
            throw new RuntimeException("Delete operation failed",e);
        }
    }
}