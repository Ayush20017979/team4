package com.learning.jobapplication.service;

import com.learning.jobapplication.model.Company;
import com.learning.jobapplication.repository.CompanyRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class CompanyServiceImpl implements CompanyService {

    private final CompanyRepository companyRepository;
    public CompanyServiceImpl(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    @Override
    public int addCompany(Company company) {
        return companyRepository.saveCompany(company);
    }

    @Override
    public int updateCompany(Company company) {
        return companyRepository.updateCompany(company);
    }

    @Override
    public int deleteCompany(Long companyId) {
        return companyRepository.deleteCompany(companyId);
    }

    @Override
    public Optional<Company> getCompany(Long companyId) {
        return companyRepository.findCompanyById(companyId);
    }

    @Override
    public List<Company> getAllCompanies() {
        return companyRepository.findAllCompanies();
    }
}
