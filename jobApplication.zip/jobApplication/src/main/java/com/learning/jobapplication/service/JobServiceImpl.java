package com.learning.jobapplication.service;

import com.learning.jobapplication.model.Job;
import com.learning.jobapplication.repository.JobRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;


@Service
public class JobServiceImpl implements JobService {

    private final JobRepository jobRepository;

    public JobServiceImpl(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    @Override
    public int addJob(Job job, Long companyId) {
        return jobRepository.addJob(job, companyId);
    }

    @Override
    public int updateJob(Long id, Job job, Long companyId) {
        return jobRepository.updateJob(id, job, companyId);
    }

    @Override
    public int deleteJob(Long id, Long companyId) {
        return jobRepository.deleteJob(id, companyId);
    }

    @Override
    public Optional<Job> getJob(Long id, Long companyId) {
        return jobRepository.getJob(id, companyId);
    }

    @Override
    public List<Job> getAllJobs(Long companyId) {
        return jobRepository.getAllJobs(companyId);
    }
}
