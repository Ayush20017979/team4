package com.learning.jobapplication.repository;

import com.learning.jobapplication.model.Job;

import java.util.List;
import java.util.Optional;

public interface JobRepository {
     int addJob(Job job , Long companyId);
     int updateJob(Long id, Job job , Long companyId);
     int deleteJob(Long id, Long companyId);
     Optional<Job> getJob(Long id , Long companyId);
     List<Job> getAllJobs(Long companyId);
}
