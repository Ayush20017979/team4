package com.learning.jobapplication.service;

import com.learning.jobapplication.model.Review;
import com.learning.jobapplication.repository.ReviewRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ReviewServiceImpl implements ReviewService{
    private final ReviewRepository reviewRepository;
    public ReviewServiceImpl(ReviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }


    @Override
    public List<Review> getAllReviews(Long companyId) {
        return reviewRepository.findReviewsByCompanyId(companyId);
    }

    @Override
    public Optional<Review> getReview(Long id, Long companyId) {
        return reviewRepository.findReviewByIdAndCompanyId(id, companyId);
    }

    @Override
    public int addReview(Review review, Long companyId) {
        return reviewRepository.addReview(review, companyId);
    }

    @Override
    public int updateReview(Long id, Review review, Long companyId) {
        return reviewRepository.updateReview(id, review, companyId);
    }

    @Override
    public int deleteReview(Long id, Long companyId) {
        return reviewRepository.deleteReview(id, companyId);
    }
}
