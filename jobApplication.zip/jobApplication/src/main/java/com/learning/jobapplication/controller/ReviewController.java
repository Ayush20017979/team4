package com.learning.jobapplication.controller;

import com.learning.jobapplication.model.Review;
import com.learning.jobapplication.service.ReviewService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/company/{companyId}/review")
public class ReviewController {
    private final ReviewService reviewService;

    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @GetMapping
    public ResponseEntity<Iterable<Review>> getAllReviews(@PathVariable Long companyId) {
        List<Review> reviews = reviewService.getAllReviews(companyId);
        if (!reviews.isEmpty()) return ResponseEntity.ok(reviews);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<?> getReview(@PathVariable Long id, @PathVariable Long companyId) {
        Optional<Review> review = reviewService.getReview(id, companyId);
        if (review.isPresent()) return ResponseEntity.ok(review.get());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No review found with the given ID for the specified company");
    }

    @PostMapping
    public ResponseEntity<?> addReview(@RequestBody Review review, @PathVariable Long companyId) {
        if (review.getTitle() == null || review.getTitle().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Review title cannot be null or empty");
        }
        int added = reviewService.addReview(review, companyId);
        if (added > 0) return ResponseEntity.status(HttpStatus.CREATED).body(review);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Review already exists or could not be added");
    }

    @PutMapping(value = "/{id}")
    public ResponseEntity<?> updateReview(@PathVariable Long id, @RequestBody Review review, @PathVariable Long companyId) {
        if (review.getTitle() == null || review.getTitle().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Review title cannot be null or empty");
        }
        int updated = reviewService.updateReview(id, review, companyId);
        if (updated > 0) return ResponseEntity.status(HttpStatus.OK).body(review);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No review found with the given ID for the specified company");
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<?> deleteReview(@PathVariable Long id, @PathVariable Long companyId){
        int deleted = reviewService.deleteReview(id, companyId);
        if (deleted > 0) return ResponseEntity.ok().build();
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No review found with the given ID for the specified company");
    }
}