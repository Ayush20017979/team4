package com.learning.jobapplication.repository;

import com.learning.jobapplication.model.Job;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class JobRepositoryImpl implements JobRepository {

    private final JdbcTemplate jdbcTemplate;

    public JobRepositoryImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private Job mapRowToJob(ResultSet rs) throws SQLException {
        return new Job(
                rs.getLong("job_id"),
                rs.getString("title"),
                rs.getString("description"),
                rs.getLong("company_id")
        );
    }


    @Override
    public int addJob(Job job, Long companyId) {
        String sql = "INSERT INTO public.job (title, description, company_id) VALUES (?, ?, ?)";
        try {
            return jdbcTemplate.update(sql, job.getTitle(), job.getDescription(), companyId);
        } catch (DataAccessException e) {
            throw new RuntimeException("Job Insert failed" , e);
        }
    }

    @Override
    public int updateJob(Long id, Job job, Long companyId) {
        String sql = "UPDATE public.job SET title = ?, description = ? WHERE company_id AND id = ?";
        try {
            return jdbcTemplate.update(sql, job.getTitle(), job.getDescription(), companyId, id);
        } catch (DataAccessException e) {
            throw new RuntimeException("Job Update failed " , e);
        }
    }

    @Override
    public int deleteJob(Long id, Long companyId) {
        String sql = "DELETE FROM public.job WHERE id = ? AND company_id";
        try {
            return jdbcTemplate.update(sql, id, companyId);
        } catch (DataAccessException e) {
            throw new RuntimeException("Job Delete failed " , e);
        }
    }

    @Override
    public Optional<Job> getJob(Long id, Long companyId) {
        String sql = "SELECT * FROM public.job WHERE id = ? AND company_id";
        try {
            return Optional.ofNullable(jdbcTemplate.queryForObject(sql,(rs,row) ->mapRowToJob(rs),id,companyId));
        } catch (DataAccessException e) {
            return Optional.empty();
        }
    }

    @Override
    public List<Job> getAllJobs(Long companyId) {
        String sql = "SELECT * FROM public.job WHERE company_id = ?";
        try {
            return jdbcTemplate.query(sql,(rs,row) ->mapRowToJob(rs),companyId);
        } catch (DataAccessException e) {
            throw new RuntimeException("Jobs retrieval failed" , e);
        }
    }
}