package com.learning.jobapplication.service;

import com.learning.jobapplication.model.Company;

import java.util.List;
import java.util.Optional;

public interface CompanyService {
     int addCompany(Company company);
     int updateCompany(Company company);
     int deleteCompany(Long companyId);
     Optional<Company> getCompany(Long companyId);
     List<Company> getAllCompanies();
}
