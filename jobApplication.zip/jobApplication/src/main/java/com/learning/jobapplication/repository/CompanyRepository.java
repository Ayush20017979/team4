package com.learning.jobapplication.repository;

import com.learning.jobapplication.model.Company;

import java.util.List;
import java.util.Optional;

public interface CompanyRepository {
     Optional<Company> findCompanyById(Long companyId);
     List<Company> findAllCompanies();
     int saveCompany(Company company);
     int updateCompany(Company company);
     int deleteCompany(Long companyId);
}
