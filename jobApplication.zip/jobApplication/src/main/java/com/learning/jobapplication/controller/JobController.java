package com.learning.jobapplication.controller;

import com.learning.jobapplication.model.Job;
import com.learning.jobapplication.service.JobService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/company/{companyId}/job")
public class JobController {
    private final JobService jobService;

    public JobController(JobService jobService) {
        this.jobService = jobService;
    }
    @GetMapping
    public ResponseEntity<Iterable<Job>> getAllJobs(@PathVariable Long companyId){
        List<Job> jobs = jobService.getAllJobs(companyId);
        if (!jobs.isEmpty()) return ResponseEntity.ok(jobs);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
    @GetMapping(value = "/{id}")
    public ResponseEntity<?> getJob(@PathVariable Long companyId , @PathVariable Long id) {
        Optional<Job> job = jobService.getJob(companyId,id);
        if (job.isPresent()) return ResponseEntity.ok(job.get());

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No job found with the given ID");

    }
    @PostMapping
    public ResponseEntity<?> addJob(@RequestBody  Job job, @PathVariable Long companyId) {
        int added = jobService.addJob(job,companyId);
        if (added > 0) return ResponseEntity.status(HttpStatus.CREATED).body(job);

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Job already exists");
    }
    @PutMapping(value = "/{id}")
    public ResponseEntity<?> updateJob(@PathVariable Long id, @RequestBody Job job , @PathVariable Long companyId) {
        int updated = jobService.updateJob(id, job, companyId);
        if (updated > 0) return ResponseEntity.status(HttpStatus.OK).body(job);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No job found with the given ID");
    }
    @DeleteMapping(value = "/{id}")
    public ResponseEntity<?> deleteJob(@PathVariable Long id, @PathVariable Long companyId) {
        int deleted = jobService.deleteJob(id , companyId);
        if (deleted > 0) return ResponseEntity.ok().build();

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No job found with the given ID");
    }
}
