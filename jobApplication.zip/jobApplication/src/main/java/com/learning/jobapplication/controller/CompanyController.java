package com.learning.jobapplication.controller;

import com.learning.jobapplication.model.Company;
import com.learning.jobapplication.service.CompanyService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/company")
public class CompanyController {

    private final CompanyService companyService;
    public CompanyController(CompanyService companyService) {
        this.companyService = companyService;
    }

    @GetMapping
    public ResponseEntity<Iterable<Company>> getAllCompanies() {
        List<Company> companies = companyService.getAllCompanies();
        if (!companies.isEmpty()) return ResponseEntity.ok(companies);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<?> getCompany(@PathVariable Long id) {
        Optional<Company> company = companyService.getCompany(id);
        if (company.isPresent()) return ResponseEntity.ok(company.get());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No company found with the given ID");
    }

    @PostMapping
    public ResponseEntity<?> addCompany(@RequestBody Company company) {
        if (company.getCompanyName() == null || company.getCompanyName().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Company name cannot be null or empty");
        }
        int added = companyService.addCompany(company);
        if (added > 0) return ResponseEntity.status(HttpStatus.CREATED).body(company);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Company already exists");
    }

    @PutMapping()
    public ResponseEntity<?> updateCompany(@RequestBody Company company) {
        if (company.getCompanyName() == null || company.getCompanyName().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Company name cannot be null or empty");
        }
        int updated = companyService.updateCompany( company);
        if (updated > 0) return ResponseEntity.status(HttpStatus.OK).body(company);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No company found with the given ID");
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<?> deleteCompany(@PathVariable Long id){
        int deleted = companyService.deleteCompany(id);
        if (deleted > 0) return ResponseEntity.ok().build();
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No company found with the given ID");
    }
}