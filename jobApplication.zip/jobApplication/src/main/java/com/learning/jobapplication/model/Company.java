package com.learning.jobapplication.model;

import java.util.List;

public class Company {
    private Long companyId;
    private String companyName;
    private String companyDescription;
    private List<Job> jobs; // One-to-many relationship with job
    private List<Review> reviews; // One-to-many relationship with review

    // Getters and setters
    public Long getCompanyId() { return companyId; }
    public void setCompanyId(Long companyId) { this.companyId = companyId; }

    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }

    public String getCompanyDescription() { return companyDescription; }
    public void setCompanyDescription(String companyDescription) { this.companyDescription = companyDescription; }

    public List<Job> getJobs() { return jobs; }
    public void setJobs(List<Job> jobs) { this.jobs = jobs; }

    public List<Review> getReviews() {return reviews;}
    public void setReviews(List<Review> reviews) {this.reviews = reviews;}

    // Constructors
    public Company(Long companyId, String companyName, String companyDescription, List<Job> jobs, List<Review> reviews) {
        this.companyId = companyId;
        this.companyName = companyName;
        this.companyDescription = companyDescription;
        this.jobs = jobs;
        this.reviews = reviews;
    }
    public Company(Long companyId, String companyName, String companyDescription) {
        this.companyId = companyId;
        this.companyName = companyName;
        this.companyDescription = companyDescription;
    }
    public Company() {}

}