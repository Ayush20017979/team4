package com.learning.jobapplication.repository;

import com.learning.jobapplication.model.Review;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class ReviewRepositoryImpl implements ReviewRepository {

    private final JdbcTemplate jdbcTemplate;

    public ReviewRepositoryImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static Review reviewMapper(ResultSet rs) throws SQLException {
        return new Review(
                rs.getLong("review_id"),
                rs.getString("title"),
                rs.getString("description"),
                rs.getDouble("rating"),
                rs.getLong("company_id")
        );
    }

    @Override
    public List<Review> findReviewsByCompanyId(Long companyId) {
        String sql = "select * from public.review where company_id=?";
        try {
            return jdbcTemplate.query(sql, (rs, row) -> reviewMapper(rs), companyId);
        } catch (DataAccessException e) {
            throw new RuntimeException("List Retrieval failed" + e);
        }
    }

    @Override
    public Optional<Review> findReviewByIdAndCompanyId(Long id, Long companyId) {
        String sql = "select * from public.review where review_id=? and company_id=?";
        try {
            return Optional.ofNullable(jdbcTemplate.queryForObject(sql, (rs, row) -> reviewMapper(rs), id, companyId));
        } catch (DataAccessException e) {
            return Optional.empty();
        }
    }

    @Override
    public int addReview(Review review, Long companyId) {
        String sql = "INSERT INTO public.review (review_id, title, description, rating, company_id) VALUES (?, ?, ?, ?, ?);";
        try {
            return jdbcTemplate.update(sql, review.getId(), review.getTitle(), review.getDescription(), review.getRating(), companyId);
        } catch (DataAccessException e) {
            throw new RuntimeException("Insert query failed " + e);
        }
    }

    @Override
    public int updateReview(Long id, Review review, Long companyId) {
        String sql = "UPDATE public.review SET title=?, description=?, rating=? WHERE review_id=? AND company_id=?";
        try {
            return jdbcTemplate.update(sql, review.getTitle(), review.getDescription(), review.getRating(), id, companyId);
        } catch (DataAccessException e) {
            throw new RuntimeException("Update query failed " + e);
        }
    }

    @Override
    public int deleteReview(Long id, Long companyId) {
        String sql = "DELETE FROM public.review WHERE review_id=? AND company_id=?";
        try {
            return jdbcTemplate.update(sql, id, companyId);
        } catch (DataAccessException e) {
            throw new RuntimeException("Delete query failed" + e);
        }
    }
}
